---
name: Discord bot lessons
description: Durable implementation constraints for this Discord bot's management and shop flows.
---

Management access must fall back to Discord's live guild owner when OAuth session permissions are stale or incomplete.

**Why:** Discord OAuth guild permission snapshots can omit or lag owner/admin privileges, which otherwise locks the real owner out of the shop panel and management commands.

**How to apply:** For panel and owner-only management checks, validate the configured FrArda owner first, then resolve and compare the current guild owner through Discord.

The admin page must preserve the OAuth session when it is opened directly: if no local token exists, redirect through Discord OAuth and accept the signed session hash on return.

**Why:** Direct panel navigation can happen before the shop page has hydrated local storage, so a correct user ID alone is not enough for the API authorization header.

**How to apply:** Keep the server-side ID check authoritative, but make the admin entry point bootstrap the same session flow as the shop.