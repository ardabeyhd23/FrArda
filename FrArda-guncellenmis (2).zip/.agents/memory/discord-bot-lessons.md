---
name: Discord bot lessons
description: Durable implementation constraints for this Discord bot's management and shop flows.
---

Management access must fall back to Discord's live guild owner when OAuth session permissions are stale or incomplete.

**Why:** Discord OAuth guild permission snapshots can omit or lag owner/admin privileges, which otherwise locks the real owner out of the shop panel and management commands.

**How to apply:** For panel and owner-only management checks, validate the configured FrArda owner first, then resolve and compare the current guild owner through Discord.